<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hayfam_Dashboard_Settings {
	const PAGE_SLUG = 'hayfam-dashboard-plugin';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_hayfam_dashboard_save', array( __CLASS__, 'save_dashboard' ) );
		add_action( 'admin_post_hayfam_dashboard_add', array( __CLASS__, 'add_dashboard' ) );
		add_action( 'admin_post_hayfam_dashboard_duplicate', array( __CLASS__, 'duplicate_dashboard' ) );
		add_action( 'admin_post_hayfam_dashboard_delete', array( __CLASS__, 'delete_dashboard' ) );
		add_action( 'admin_post_hayfam_dashboard_clear_cache', array( __CLASS__, 'clear_cache' ) );
	}

	public static function defaults() {
		return array(
			'source_url'    => '',
			'default_sheet' => 'WebsiteData',
			'cache_ttl'     => 300,
			'debug'         => 0,
			'dashboards'    => array(),
		);
	}

	public static function dashboard_defaults( $id = 'dashboard', $label = 'Dashboard' ) {
		return array(
			'id'        => sanitize_key( $id ),
			'label'     => sanitize_text_field( $label ),
			'shortcode' => 'dashboard_' . sanitize_key( $id ),
			'source_url'=> '',
			'sheet'     => 'WebsiteData',
			'cell'      => 'B2',
			'before'    => 'So far we have saved',
			'after'     => 'Of food from landfill',
			'prefix'    => '',
			'suffix'    => ' KG',
			'override'  => '',
			'decimals'  => '-1',
			'thousands' => ',',
			'decimal'   => '.',
			'fallback'  => 'Data currently unavailable',
			'cache_ttl' => 300,
			'class'     => '',
			'font_family'      => 'inherit',
			'font_size'        => '',
			'value_font_size'  => '',
			'font_weight'      => '',
			'value_font_weight'=> '',
			'line_height'      => '',
			'text_align'       => '',
			'before_color'     => '',
			'value_color'      => '',
			'after_color'      => '',
			'background_color' => '',
			'gap'              => '',
			'padding'          => '',
			'border_radius'    => '',
			'widget_preset'    => 'plain',
			'widget_border'    => 'none',
			'widget_background'=> 'transparent',
			'widget_graphic'   => 'none',
		);
	}

	public static function get_all() {
		$stored     = get_option( HAYFAM_DASHBOARD_SETTINGS_OPTION, array() );
		$stored     = is_array( $stored ) ? $stored : array();
		$settings   = wp_parse_args( $stored, self::defaults() );
		$dashboards = isset( $stored['dashboards'] ) && is_array( $stored['dashboards'] ) ? $stored['dashboards'] : array();

		// Convert the original v2 single-dashboard settings into the first tab.
		if ( empty( $dashboards ) ) {
			$legacy = self::dashboard_defaults( 'dashboard', 'Dashboard' );
			$legacy['source_url'] = isset( $stored['source_url'] ) ? esc_url_raw( $stored['source_url'] ) : '';
			$legacy['sheet']      = isset( $stored['default_sheet'] ) ? sanitize_text_field( $stored['default_sheet'] ) : $legacy['sheet'];
			$legacy['cache_ttl']  = isset( $stored['cache_ttl'] ) ? max( 60, absint( $stored['cache_ttl'] ) ) : $legacy['cache_ttl'];
			$dashboards           = array( 'dashboard' => $legacy );
		}

		$normalised = array();
		foreach ( $dashboards as $key => $dashboard ) {
			$id = sanitize_key( $key );
			if ( ! $id ) {
				continue;
			}

			$defaults             = self::dashboard_defaults( $id, ucfirst( str_replace( array( '-', '_' ), ' ', $id ) ) );
			$dashboard            = is_array( $dashboard ) ? wp_parse_args( $dashboard, $defaults ) : $defaults;
			$dashboard['id']      = $id;
			$dashboard['label']   = sanitize_text_field( $dashboard['label'] );
			$dashboard['shortcode'] = sanitize_key( $dashboard['shortcode'] );

			if ( ! $dashboard['shortcode'] || 'dashboard_metric' === $dashboard['shortcode'] ) {
				$dashboard['shortcode'] = 'dashboard_' . $id;
			}

			$normalised[ $id ] = $dashboard;
		}

		if ( empty( $normalised ) ) {
			$normalised['dashboard'] = self::dashboard_defaults();
		}

		$settings['source_url']    = esc_url_raw( $settings['source_url'] );
		$settings['default_sheet'] = sanitize_text_field( $settings['default_sheet'] );
		$settings['cache_ttl']     = max( 60, absint( $settings['cache_ttl'] ) );
		$settings['debug']         = empty( $settings['debug'] ) ? 0 : 1;
		$settings['dashboards']    = $normalised;

		return $settings;
	}

	public static function get_dashboards() {
		$settings = self::get_all();
		return $settings['dashboards'];
	}

	public static function get_dashboard( $id = '' ) {
		$dashboards = self::get_dashboards();
		$id         = sanitize_key( $id );

		if ( $id && isset( $dashboards[ $id ] ) ) {
			return $dashboards[ $id ];
		}

		if ( $id ) {
			foreach ( $dashboards as $dashboard ) {
				if ( $id === $dashboard['shortcode'] ) {
					return $dashboard;
				}
			}
		}

		return reset( $dashboards );
	}

	public static function make_id( $label, $existing ) {
		$id     = str_replace( '-', '_', sanitize_title( $label ) );
		$id     = $id ? $id : 'dashboard';
		$base   = $id;
		$number = 2;

		while ( isset( $existing[ $id ] ) ) {
			$id = $base . '_' . $number;
			$number++;
		}

		return $id;
	}

	public static function save_dashboard() {
		self::verify_admin_request( 'hayfam_dashboard_save' );

		$dashboard_id = isset( $_POST['dashboard_id'] ) ? sanitize_key( wp_unslash( $_POST['dashboard_id'] ) ) : '';
		$input        = isset( $_POST['dashboard'] ) && is_array( $_POST['dashboard'] ) ? wp_unslash( $_POST['dashboard'] ) : array();
		$settings     = self::get_all();

		if ( ! $dashboard_id || ! isset( $settings['dashboards'][ $dashboard_id ] ) ) {
			self::redirect( '', 'error' );
		}

		$updated_dashboard = self::sanitize_dashboard( $input, $settings['dashboards'][ $dashboard_id ] );
		$updated_dashboard['shortcode'] = self::unique_shortcode( $updated_dashboard['shortcode'], $dashboard_id, $settings['dashboards'] );
		$settings['dashboards'][ $dashboard_id ] = $updated_dashboard;
		$settings['debug'] = empty( $_POST['debug'] ) ? 0 : 1;
		self::sync_legacy_values( $settings, $dashboard_id );
		update_option( HAYFAM_DASHBOARD_SETTINGS_OPTION, $settings );

		self::redirect( $dashboard_id, 'saved' );
	}

	public static function add_dashboard() {
		self::verify_admin_request( 'hayfam_dashboard_add' );

		$settings = self::get_all();
		$id       = self::make_id( 'New Dashboard', $settings['dashboards'] );
		$settings['dashboards'][ $id ] = self::dashboard_defaults( $id, 'New Dashboard' );
		update_option( HAYFAM_DASHBOARD_SETTINGS_OPTION, $settings );

		self::redirect( $id, 'added' );
	}

	public static function duplicate_dashboard() {
		self::verify_admin_request( 'hayfam_dashboard_duplicate' );

		$dashboard_id = isset( $_POST['dashboard_id'] ) ? sanitize_key( wp_unslash( $_POST['dashboard_id'] ) ) : '';
		$settings     = self::get_all();

		if ( ! $dashboard_id || ! isset( $settings['dashboards'][ $dashboard_id ] ) ) {
			self::redirect( $dashboard_id, 'error' );
		}

		$source      = $settings['dashboards'][ $dashboard_id ];
		$new_label   = $source['label'] . ' Copy';
		$new_id      = self::make_id( $new_label, $settings['dashboards'] );
		$duplicate   = $source;
		$duplicate['id'] = $new_id;
		$duplicate['label'] = $new_label;
		$duplicate['shortcode'] = self::unique_shortcode( 'dashboard_' . $new_id, $new_id, $settings['dashboards'] );
		$settings['dashboards'][ $new_id ] = $duplicate;

		update_option( HAYFAM_DASHBOARD_SETTINGS_OPTION, $settings );
		self::redirect( $new_id, 'duplicated' );
	}

	public static function delete_dashboard() {
		self::verify_admin_request( 'hayfam_dashboard_delete' );

		$dashboard_id = isset( $_POST['dashboard_id'] ) ? sanitize_key( wp_unslash( $_POST['dashboard_id'] ) ) : '';
		$settings     = self::get_all();

		if ( count( $settings['dashboards'] ) <= 1 || ! isset( $settings['dashboards'][ $dashboard_id ] ) ) {
			self::redirect( $dashboard_id, 'error' );
		}

		unset( $settings['dashboards'][ $dashboard_id ] );
		$next_id = key( $settings['dashboards'] );
		self::sync_legacy_values( $settings, $next_id );
		update_option( HAYFAM_DASHBOARD_SETTINGS_OPTION, $settings );

		self::redirect( $next_id, 'deleted' );
	}

	public static function clear_cache() {
		self::verify_admin_request( 'hayfam_dashboard_clear_cache' );
		Hayfam_Dashboard_Cache::clear();
		self::redirect( isset( $_POST['dashboard_id'] ) ? sanitize_key( wp_unslash( $_POST['dashboard_id'] ) ) : '', 'cache_cleared' );
	}

	public static function register_menu() {
		add_options_page( __( 'Dashboard Plugin', 'dashboard-plugin' ), __( 'Dashboard Plugin', 'dashboard-plugin' ), 'manage_options', self::PAGE_SLUG, array( __CLASS__, 'render_page' ) );
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings   = self::get_all();
		$dashboards = $settings['dashboards'];
		$current_id = isset( $_GET['dashboard'] ) ? sanitize_key( wp_unslash( $_GET['dashboard'] ) ) : key( $dashboards );
		$current_id = isset( $dashboards[ $current_id ] ) ? $current_id : key( $dashboards );
		$current    = $dashboards[ $current_id ];
		$base_url   = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
		$message    = isset( $_GET['message'] ) ? sanitize_key( wp_unslash( $_GET['message'] ) ) : '';
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Dashboard Plugin v2.5.0', 'dashboard-plugin' ); ?></h1>
			<p><?php echo esc_html__( 'Create a separate tab and shortcode for each live dashboard metric.', 'dashboard-plugin' ); ?></p>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $dashboards as $id => $dashboard ) : ?>
					<a class="nav-tab <?php echo $id === $current_id ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'dashboard', $id, $base_url ) ); ?>"><?php echo esc_html( $dashboard['label'] ); ?></a>
				<?php endforeach; ?>
				<a class="nav-tab" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hayfam_dashboard_add' ), 'hayfam_dashboard_add' ) ); ?>">+ <?php echo esc_html__( 'Add dashboard', 'dashboard-plugin' ); ?></a>
			</h2>

			<?php if ( 'saved' === $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Dashboard saved.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>
			<?php if ( 'added' === $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Dashboard added.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>
			<?php if ( 'duplicated' === $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Dashboard duplicated.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>
			<?php if ( 'deleted' === $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Dashboard deleted.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>
			<?php if ( 'cache_cleared' === $message ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Cached dashboard values cleared.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>
			<?php if ( 'error' === $message ) : ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'The requested dashboard action could not be completed.', 'dashboard-plugin' ); ?></p></div><?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="hayfam_dashboard_save">
				<input type="hidden" name="dashboard_id" value="<?php echo esc_attr( $current_id ); ?>">
				<?php wp_nonce_field( 'hayfam_dashboard_save' ); ?>

				<h2><?php echo esc_html__( 'Dashboard details', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-label"><?php echo esc_html__( 'Dashboard name', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-label" class="regular-text" type="text" name="dashboard[label]" value="<?php echo esc_attr( $current['label'] ); ?>" required><p class="description"><?php echo esc_html__( 'This name appears on the settings tab.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><?php echo esc_html__( 'Shortcode', 'dashboard-plugin' ); ?></th><td><code>[<?php echo esc_html( $current['shortcode'] ); ?>]</code><p class="description"><?php echo esc_html__( 'Use this unique shortcode in Elementor, WordPress, or any page builder shortcode block.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-shortcode"><?php echo esc_html__( 'Shortcode name', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-shortcode" class="regular-text" type="text" name="dashboard[shortcode]" value="<?php echo esc_attr( $current['shortcode'] ); ?>" pattern="[A-Za-z0-9_-]+"><p class="description"><?php echo esc_html__( 'Use lowercase letters, numbers, or underscores. The plugin adds the dashboard_ prefix if needed. Avoid changing this after placing the shortcode on a page.', 'dashboard-plugin' ); ?></p></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Google Sheet source', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-source"><?php echo esc_html__( 'Published sheet URL', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-source" class="large-text" type="url" name="dashboard[source_url]" value="<?php echo esc_attr( $current['source_url'] ); ?>" placeholder="https://docs.google.com/spreadsheets/d/.../pub"><p class="description"><?php echo esc_html__( 'Use a published, non-sensitive Google Sheet or output tab. This can be left blank while an override figure is being used.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-sheet"><?php echo esc_html__( 'Worksheet/tab', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-sheet" class="regular-text" type="text" name="dashboard[sheet]" value="<?php echo esc_attr( $current['sheet'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-cell"><?php echo esc_html__( 'Cell reference', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-cell" class="small-text" type="text" name="dashboard[cell]" value="<?php echo esc_attr( $current['cell'] ); ?>" required><p class="description"><?php echo esc_html__( 'For example B2 or C5.', 'dashboard-plugin' ); ?></p></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Displayed content', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-before"><?php echo esc_html__( 'Text above value', 'dashboard-plugin' ); ?></label></th><td><textarea id="hayfam-dashboard-before" class="large-text" rows="2" name="dashboard[before]"><?php echo esc_textarea( $current['before'] ); ?></textarea></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-after"><?php echo esc_html__( 'Text below value', 'dashboard-plugin' ); ?></label></th><td><textarea id="hayfam-dashboard-after" class="large-text" rows="2" name="dashboard[after]"><?php echo esc_textarea( $current['after'] ); ?></textarea></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-prefix"><?php echo esc_html__( 'Value prefix', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-prefix" class="regular-text" type="text" name="dashboard[prefix]" value="<?php echo esc_attr( $current['prefix'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-suffix"><?php echo esc_html__( 'Value suffix', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-suffix" class="regular-text" type="text" name="dashboard[suffix]" value="<?php echo esc_attr( $current['suffix'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-override"><?php echo esc_html__( 'Override figure', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-override" class="regular-text" type="text" name="dashboard[override]" value="<?php echo esc_attr( $current['override'] ); ?>" placeholder="Leave blank to use Google Sheet"><p class="description"><?php echo esc_html__( 'If this field contains a value, it is displayed instead of the Google Sheet value. Leave it blank to use the Google Sheet. This is useful for testing before the sheet is connected.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-fallback"><?php echo esc_html__( 'Fallback message', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-fallback" class="regular-text" type="text" name="dashboard[fallback]" value="<?php echo esc_attr( $current['fallback'] ); ?>"></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Typography', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-font-family"><?php echo esc_html__( 'Font family', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-font-family" name="dashboard[font_family]"><?php foreach ( self::font_family_options() as $font_key => $font_label ) : ?><option value="<?php echo esc_attr( $font_key ); ?>" <?php selected( $current['font_family'], $font_key ); ?>><?php echo esc_html( $font_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-font-size"><?php echo esc_html__( 'Text size', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-font-size" class="small-text" type="text" name="dashboard[font_size]" value="<?php echo esc_attr( $current['font_size'] ); ?>" placeholder="e.g. 18px or 18"><p class="description"><?php echo esc_html__( 'Applies to the dashboard text. Enter a number for pixels, or include a unit such as px, em, rem, %, vw, or vh. Leave blank to use the theme size.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-value-font-size"><?php echo esc_html__( 'Value size', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-value-font-size" class="small-text" type="text" name="dashboard[value_font_size]" value="<?php echo esc_attr( $current['value_font_size'] ); ?>" placeholder="e.g. 48px or 48"><p class="description"><?php echo esc_html__( 'Controls the figure size independently. A bare number is treated as pixels.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-font-weight"><?php echo esc_html__( 'Text weight', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-font-weight" name="dashboard[font_weight]"><option value=""><?php echo esc_html__( 'Theme default', 'dashboard-plugin' ); ?></option><?php foreach ( array( '400' => 'Normal', '500' => 'Medium', '600' => 'Semi-bold', '700' => 'Bold', '800' => 'Extra-bold' ) as $weight_key => $weight_label ) : ?><option value="<?php echo esc_attr( $weight_key ); ?>" <?php selected( $current['font_weight'], $weight_key ); ?>><?php echo esc_html( $weight_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-value-font-weight"><?php echo esc_html__( 'Value weight', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-value-font-weight" name="dashboard[value_font_weight]"><option value=""><?php echo esc_html__( 'Theme default', 'dashboard-plugin' ); ?></option><?php foreach ( array( '400' => 'Normal', '500' => 'Medium', '600' => 'Semi-bold', '700' => 'Bold', '800' => 'Extra-bold' ) as $weight_key => $weight_label ) : ?><option value="<?php echo esc_attr( $weight_key ); ?>" <?php selected( $current['value_font_weight'], $weight_key ); ?>><?php echo esc_html( $weight_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-line-height"><?php echo esc_html__( 'Line height', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-line-height" class="small-text" type="text" name="dashboard[line_height]" value="<?php echo esc_attr( $current['line_height'] ); ?>" placeholder="e.g. 1.3"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-text-align"><?php echo esc_html__( 'Text alignment', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-text-align" name="dashboard[text_align]"><option value=""><?php echo esc_html__( 'Theme default', 'dashboard-plugin' ); ?></option><?php foreach ( array( 'left' => 'Left', 'center' => 'Centre', 'right' => 'Right' ) as $align_key => $align_label ) : ?><option value="<?php echo esc_attr( $align_key ); ?>" <?php selected( $current['text_align'], $align_key ); ?>><?php echo esc_html( $align_label ); ?></option><?php endforeach; ?></select></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Colours', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-before-color"><?php echo esc_html__( 'Text above colour', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-before-color" class="regular-text" type="text" name="dashboard[before_color]" value="<?php echo esc_attr( $current['before_color'] ); ?>" placeholder="#333333"><p class="description"><?php echo esc_html__( 'Use a six- or three-digit hex colour, or leave blank for the theme colour.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-value-color"><?php echo esc_html__( 'Value colour', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-value-color" class="regular-text" type="text" name="dashboard[value_color]" value="<?php echo esc_attr( $current['value_color'] ); ?>" placeholder="#2f855a"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-after-color"><?php echo esc_html__( 'Text below colour', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-after-color" class="regular-text" type="text" name="dashboard[after_color]" value="<?php echo esc_attr( $current['after_color'] ); ?>" placeholder="#333333"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-background-color"><?php echo esc_html__( 'Background colour', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-background-color" class="regular-text" type="text" name="dashboard[background_color]" value="<?php echo esc_attr( $current['background_color'] ); ?>" placeholder="#ffffff"></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Spacing and shape', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-gap"><?php echo esc_html__( 'Space between lines', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-gap" class="small-text" type="text" name="dashboard[gap]" value="<?php echo esc_attr( $current['gap'] ); ?>" placeholder="e.g. 8px"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-padding"><?php echo esc_html__( 'Inner padding', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-padding" class="small-text" type="text" name="dashboard[padding]" value="<?php echo esc_attr( $current['padding'] ); ?>" placeholder="e.g. 16px"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-border-radius"><?php echo esc_html__( 'Corner radius', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-border-radius" class="small-text" type="text" name="dashboard[border_radius]" value="<?php echo esc_attr( $current['border_radius'] ); ?>" placeholder="e.g. 8px"></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Widget appearance', 'dashboard-plugin' ); ?></h2>
				<p class="description"><?php echo esc_html__( 'Choose a ready-made widget treatment. These options add the visual card, border, background, and decorative graphic without requiring CSS.', 'dashboard-plugin' ); ?></p>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-widget-preset"><?php echo esc_html__( 'Widget style', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-widget-preset" name="dashboard[widget_preset]"><?php foreach ( self::widget_preset_options() as $widget_key => $widget_label ) : ?><option value="<?php echo esc_attr( $widget_key ); ?>" <?php selected( $current['widget_preset'], $widget_key ); ?>><?php echo esc_html( $widget_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-widget-border"><?php echo esc_html__( 'Border style', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-widget-border" name="dashboard[widget_border]"><?php foreach ( self::widget_border_options() as $widget_key => $widget_label ) : ?><option value="<?php echo esc_attr( $widget_key ); ?>" <?php selected( $current['widget_border'], $widget_key ); ?>><?php echo esc_html( $widget_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-widget-background"><?php echo esc_html__( 'Background treatment', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-widget-background" name="dashboard[widget_background]"><?php foreach ( self::widget_background_options() as $widget_key => $widget_label ) : ?><option value="<?php echo esc_attr( $widget_key ); ?>" <?php selected( $current['widget_background'], $widget_key ); ?>><?php echo esc_html( $widget_label ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-widget-graphic"><?php echo esc_html__( 'Decorative graphic', 'dashboard-plugin' ); ?></label></th><td><select id="hayfam-dashboard-widget-graphic" name="dashboard[widget_graphic]"><?php foreach ( self::widget_graphic_options() as $widget_key => $widget_label ) : ?><option value="<?php echo esc_attr( $widget_key ); ?>" <?php selected( $current['widget_graphic'], $widget_key ); ?>><?php echo esc_html( $widget_label ); ?></option><?php endforeach; ?></select></td></tr>
				</table>

				<h2><?php echo esc_html__( 'Formatting and caching', 'dashboard-plugin' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hayfam-dashboard-decimals"><?php echo esc_html__( 'Decimal places', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-decimals" class="small-text" type="number" name="dashboard[decimals]" value="<?php echo esc_attr( $current['decimals'] ); ?>" min="-1" max="10"><p class="description"><?php echo esc_html__( '-1 preserves the source value.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-thousands"><?php echo esc_html__( 'Thousands separator', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-thousands" class="small-text" type="text" name="dashboard[thousands]" value="<?php echo esc_attr( $current['thousands'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-decimal"><?php echo esc_html__( 'Decimal separator', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-decimal" class="small-text" type="text" name="dashboard[decimal]" value="<?php echo esc_attr( $current['decimal'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-cache"><?php echo esc_html__( 'Cache duration (seconds)', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-cache" class="small-text" type="number" name="dashboard[cache_ttl]" value="<?php echo esc_attr( $current['cache_ttl'] ); ?>" min="60"></td></tr>
					<tr><th scope="row"><label for="hayfam-dashboard-class"><?php echo esc_html__( 'Custom CSS class', 'dashboard-plugin' ); ?></label></th><td><input id="hayfam-dashboard-class" class="regular-text" type="text" name="dashboard[class]" value="<?php echo esc_attr( $current['class'] ); ?>"><p class="description"><?php echo esc_html__( 'Optional advanced class for additional theme or CSS styling.', 'dashboard-plugin' ); ?></p></td></tr>
					<tr><th scope="row"><?php echo esc_html__( 'Debug logging', 'dashboard-plugin' ); ?></th><td><label><input type="checkbox" name="debug" value="1" <?php checked( ! empty( $settings['debug'] ), true ); ?>> <?php echo esc_html__( 'Write diagnostic messages when WP_DEBUG is enabled.', 'dashboard-plugin' ); ?></label></td></tr>
				</table>

				<?php submit_button( __( 'Save dashboard', 'dashboard-plugin' ) ); ?>
			</form>

			<div class="hayfam-dashboard-admin-preview" style="max-width:560px;margin:24px 0;padding:20px 24px;border:1px solid #c3c4c7;border-radius:6px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.04)">
				<h2 style="margin-top:0"><?php echo esc_html__( 'Dashboard preview', 'dashboard-plugin' ); ?></h2>
				<p class="description"><?php echo esc_html__( 'This preview uses the last saved settings for this dashboard. Save changes above to refresh it.', 'dashboard-plugin' ); ?></p>
				<div style="margin-top:18px;padding:24px;text-align:center;background:#f6f7f7;border-radius:4px;font-size:18px;line-height:1.35">
					<style>
						.hayfam-dashboard-admin-preview .hayfam-dashboard-metric { align-items: center; }
						.hayfam-dashboard-admin-preview .hayfam-dashboard-metric__value { margin: 8px 0; font-size: var(--hayfam-dashboard-value-font-size, 2.5em); font-weight: var(--hayfam-dashboard-value-font-weight, 700); line-height: 1; }
					</style>
					<?php echo wp_kses_post( Hayfam_Dashboard_Shortcode::render_preview( $current_id ) ); ?>
				</div>
			</div>

			<hr>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:12px">
				<input type="hidden" name="action" value="hayfam_dashboard_clear_cache">
				<input type="hidden" name="dashboard_id" value="<?php echo esc_attr( $current_id ); ?>">
				<?php wp_nonce_field( 'hayfam_dashboard_clear_cache' ); ?>
				<?php submit_button( __( 'Clear cached values', 'dashboard-plugin' ), 'secondary', 'submit', false ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:12px">
				<input type="hidden" name="action" value="hayfam_dashboard_duplicate">
				<input type="hidden" name="dashboard_id" value="<?php echo esc_attr( $current_id ); ?>">
				<?php wp_nonce_field( 'hayfam_dashboard_duplicate' ); ?>
				<?php submit_button( __( 'Duplicate this dashboard', 'dashboard-plugin' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php if ( count( $dashboards ) > 1 ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
					<input type="hidden" name="action" value="hayfam_dashboard_delete">
					<input type="hidden" name="dashboard_id" value="<?php echo esc_attr( $current_id ); ?>">
					<?php wp_nonce_field( 'hayfam_dashboard_delete' ); ?>
					<?php submit_button( __( 'Delete this dashboard', 'dashboard-plugin' ), 'delete', 'submit', false, array( 'onclick' => "return confirm('Delete this dashboard?');" ) ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function sanitize_dashboard( $input, $current ) {
		$dashboard = wp_parse_args( is_array( $input ) ? $input : array(), $current );
		$dashboard['label']      = sanitize_text_field( $dashboard['label'] );
		$shortcode                = sanitize_key( $dashboard['shortcode'] );
		$shortcode                = 'dashboard_metric' === $shortcode ? '' : $shortcode;
		$dashboard['shortcode']   = $shortcode ? ( 0 === strpos( $shortcode, 'dashboard_' ) ? $shortcode : 'dashboard_' . $shortcode ) : $current['shortcode'];
		$dashboard['source_url'] = esc_url_raw( trim( $dashboard['source_url'] ) );
		$dashboard['sheet']      = sanitize_text_field( $dashboard['sheet'] );
		$dashboard['cell']       = strtoupper( preg_replace( '/\s+/', '', sanitize_text_field( $dashboard['cell'] ) ) );
		$dashboard['before']     = sanitize_textarea_field( $dashboard['before'] );
		$dashboard['after']      = sanitize_textarea_field( $dashboard['after'] );
		$dashboard['prefix']     = sanitize_text_field( $dashboard['prefix'] );
		$dashboard['suffix']     = sanitize_text_field( $dashboard['suffix'] );
		$dashboard['override']   = sanitize_text_field( $dashboard['override'] );
		$dashboard['decimals']   = (string) max( -1, min( 10, (int) $dashboard['decimals'] ) );
		$dashboard['thousands']  = substr( sanitize_text_field( $dashboard['thousands'] ), 0, 1 );
		$dashboard['decimal']    = substr( sanitize_text_field( $dashboard['decimal'] ), 0, 1 );
		$dashboard['fallback']   = sanitize_text_field( $dashboard['fallback'] );
		$dashboard['cache_ttl']  = max( 60, absint( $dashboard['cache_ttl'] ) );
		$dashboard['class']      = sanitize_text_field( $dashboard['class'] );
		$dashboard['font_family']       = sanitize_key( (string) $dashboard['font_family'] );
		$dashboard['font_family']       = array_key_exists( $dashboard['font_family'], self::font_family_options() ) ? $dashboard['font_family'] : 'inherit';
		$dashboard['font_size']         = self::sanitize_css_length( $dashboard['font_size'] );
		$dashboard['value_font_size']   = self::sanitize_css_length( $dashboard['value_font_size'] );
		$dashboard['font_weight']       = in_array( (string) $dashboard['font_weight'], array( '400', '500', '600', '700', '800' ), true ) ? (string) $dashboard['font_weight'] : '';
		$dashboard['value_font_weight'] = in_array( (string) $dashboard['value_font_weight'], array( '400', '500', '600', '700', '800' ), true ) ? (string) $dashboard['value_font_weight'] : '';
		$dashboard['line_height']       = self::sanitize_css_line_height( $dashboard['line_height'] );
		$dashboard['text_align']        = in_array( $dashboard['text_align'], array( 'left', 'center', 'right' ), true ) ? $dashboard['text_align'] : '';
		$dashboard['before_color']      = sanitize_hex_color( $dashboard['before_color'] ) ?: '';
		$dashboard['value_color']       = sanitize_hex_color( $dashboard['value_color'] ) ?: '';
		$dashboard['after_color']       = sanitize_hex_color( $dashboard['after_color'] ) ?: '';
		$dashboard['background_color']  = sanitize_hex_color( $dashboard['background_color'] ) ?: '';
		$dashboard['gap']               = self::sanitize_css_length( $dashboard['gap'] );
		$dashboard['padding']           = self::sanitize_css_length( $dashboard['padding'] );
		$dashboard['border_radius']     = self::sanitize_css_length( $dashboard['border_radius'] );
		$dashboard['widget_preset']     = array_key_exists( $dashboard['widget_preset'], self::widget_preset_options() ) ? $dashboard['widget_preset'] : 'plain';
		$dashboard['widget_border']     = array_key_exists( $dashboard['widget_border'], self::widget_border_options() ) ? $dashboard['widget_border'] : 'none';
		$dashboard['widget_background'] = array_key_exists( $dashboard['widget_background'], self::widget_background_options() ) ? $dashboard['widget_background'] : 'transparent';
		$dashboard['widget_graphic']    = array_key_exists( $dashboard['widget_graphic'], self::widget_graphic_options() ) ? $dashboard['widget_graphic'] : 'none';

		if ( ! preg_match( '/^[A-Z]+[1-9][0-9]*$/', $dashboard['cell'] ) ) {
			$dashboard['cell'] = 'B2';
		}

		if ( ! Hayfam_Dashboard_Sheets_Client::is_supported_url( $dashboard['source_url'] ) ) {
			$dashboard['source_url'] = '';
		}

		return $dashboard;
	}

	public static function font_family_options() {
		return array(
			'inherit'   => __( 'Theme default', 'dashboard-plugin' ),
			'system'    => __( 'System sans-serif', 'dashboard-plugin' ),
			'arial'     => 'Arial',
			'georgia'   => 'Georgia',
			'courier'   => 'Courier New',
			'trebuchet' => 'Trebuchet MS',
			'verdana'   => 'Verdana',
		);
	}

	public static function widget_preset_options() {
		return array(
			'plain'          => __( 'Plain', 'dashboard-plugin' ),
			'soft_card'      => __( 'Soft card', 'dashboard-plugin' ),
			'outlined_card'  => __( 'Outlined card', 'dashboard-plugin' ),
			'dark_card'      => __( 'Dark card', 'dashboard-plugin' ),
			'gradient_card'  => __( 'Gradient card', 'dashboard-plugin' ),
		);
	}

	public static function widget_border_options() {
		return array(
			'none'   => __( 'No border', 'dashboard-plugin' ),
			'solid'  => __( 'Solid', 'dashboard-plugin' ),
			'dashed' => __( 'Dashed', 'dashboard-plugin' ),
			'double' => __( 'Double', 'dashboard-plugin' ),
			'accent' => __( 'Accent colour', 'dashboard-plugin' ),
		);
	}

	public static function widget_background_options() {
		return array(
			'transparent'    => __( 'Transparent', 'dashboard-plugin' ),
			'white'          => __( 'White', 'dashboard-plugin' ),
			'soft_grey'      => __( 'Soft grey', 'dashboard-plugin' ),
			'warm'           => __( 'Warm cream', 'dashboard-plugin' ),
			'dark'           => __( 'Dark', 'dashboard-plugin' ),
			'green_gradient' => __( 'Green gradient', 'dashboard-plugin' ),
			'blue_gradient'  => __( 'Blue gradient', 'dashboard-plugin' ),
		);
	}

	public static function widget_graphic_options() {
		return array(
			'none'          => __( 'None', 'dashboard-plugin' ),
			'top_stripe'    => __( 'Top accent stripe', 'dashboard-plugin' ),
			'corner_circles'=> __( 'Corner circles', 'dashboard-plugin' ),
			'dots'          => __( 'Dot pattern', 'dashboard-plugin' ),
			'side_bars'     => __( 'Side bars', 'dashboard-plugin' ),
		);
	}

	private static function sanitize_css_length( $value ) {
		$value = trim( sanitize_text_field( (string) $value ) );
		if ( '0' === $value || preg_match( '/^[0-9]+(?:\.[0-9]+)?(?:px|em|rem|%|vw|vh)$/', $value ) ) {
			return $value;
		}

		return preg_match( '/^[0-9]+(?:\.[0-9]+)?$/', $value ) ? $value . 'px' : '';
	}

	private static function sanitize_css_line_height( $value ) {
		$value = trim( sanitize_text_field( (string) $value ) );
		return preg_match( '/^(?:normal|[0-9]+(?:\.[0-9]+)?)$/', $value ) ? $value : '';
	}

	private static function unique_shortcode( $shortcode, $dashboard_id, $dashboards ) {
		$base   = $shortcode ? $shortcode : 'dashboard_' . $dashboard_id;
		$unique = $base;
		$number = 2;

		do {
			$collision = false;
			foreach ( $dashboards as $id => $dashboard ) {
				if ( $id !== $dashboard_id && isset( $dashboard['shortcode'] ) && $dashboard['shortcode'] === $unique ) {
					$unique    = $base . '_' . $number;
					$number++;
					$collision = true;
					break;
				}
			}
		} while ( $collision );

		return $unique;
	}

	private static function sync_legacy_values( &$settings, $dashboard_id ) {
		if ( isset( $settings['dashboards'][ $dashboard_id ] ) ) {
			$dashboard                = $settings['dashboards'][ $dashboard_id ];
			$settings['source_url']    = $dashboard['source_url'];
			$settings['default_sheet'] = $dashboard['sheet'];
			$settings['cache_ttl']     = $dashboard['cache_ttl'];
		}
	}

	private static function verify_admin_request( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'dashboard-plugin' ) );
		}

		check_admin_referer( $action );
	}

	private static function redirect( $dashboard_id, $message ) {
		$args = array( 'page' => self::PAGE_SLUG, 'message' => $message );
		if ( $dashboard_id ) {
			$args['dashboard'] = $dashboard_id;
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
